import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Ban, CheckCircle2, Eye, Pencil, ShieldCheck, Trash2, Unlock, XCircle } from 'lucide-react'
import { DataTable } from '../components/DataTable'
import { ProductSelect } from '../components/ProductSelect'
import { Card, Confirm, ErrorState, Field, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, jsonBody, queryString } from '../lib/api'
import { useDebouncedValue } from '../lib/hooks'
import { dateTimeFa } from '../lib/format'
import type { Artist, ArtistAuth, Paginated } from '../lib/types'
import { useRemote } from '../lib/useRemote'
import { mutationFieldsMatch, pageSnapshot, reconcilePaginatedStable, removePaginatedItem, setPaginatedItem, verifyExactEntity } from '../lib/mutationSync'

export default function ArtistsPage() {
  const [params] = useSearchParams()
  const [tab, setTab] = useState<'artists'|'pending'>('artists')
  const [search, setSearch] = useState(() => params.get('q') || '')
  const [verified, setVerified] = useState('')
  const [artistPage, setArtistPage] = useState(1)
  const [pendingPage, setPendingPage] = useState(1)
  const [artist, setArtist] = useState<Artist | null>(null)
  const [application, setApplication] = useState<ArtistAuth | null>(null)
  const [banTarget, setBanTarget] = useState<Artist | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Artist | null>(null)
  const [busy, setBusy] = useState(false)
  const [verifyingArtistId, setVerifyingArtistId] = useState<number | null>(null)
  const [draft, setDraft] = useState<Record<string,string>>({})
  const q = useDebouncedValue(search)
  const toast = useToast()
  const artists = useRemote<Paginated<Artist>>('/admin/artists/' + queryString({ q, verified, page:artistPage, page_size:20 }), [q, verified, artistPage])
  const pending = useRemote<Paginated<ArtistAuth>>('/admin/pend_artists/' + queryString({ page:pendingPage, page_size:20 }), [pendingPage])

  const artistVisible=(item:Artist)=>verified===''||String(item.verified)===verified
  const verifyArtistExact=(item:Artist,snapshot=pageSnapshot(artists.data,item.id),refreshPage=false,expect?:{verified?:boolean;banned?:boolean;missing?:boolean;saved?:boolean})=>{
    void verifyExactEntity<Artist>(`/admin/artists/${item.id}/`,{
      found:server=>artists.setData(current=>setPaginatedItem(current,server,{visible:artistVisible(server),indexHint:snapshot.index})),
      missing:()=>artists.setData(current=>removePaginatedItem(current,item.id)),
    },expect?.missing?{stopOnMissing:true}:expect?.verified!==undefined?{stopWhenFound:server=>server.verified===expect.verified}:expect?.banned!==undefined?{stopWhenFound:server=>server.user_is_banned===expect.banned}:expect?.saved?{stopWhenFound:server=>mutationFieldsMatch(server,item,['name','name_en','artistic_name','artistic_name_en','email','city','city_en','bio','bio_en'])}:{}).then(outcome=>{if(refreshPage&&outcome!=='superseded')void artists.revalidate((current,incoming)=>reconcilePaginatedStable(current,incoming,snapshot.order))})
  }
  function editArtist(item: Artist) { setArtist(item); setDraft({ name:item.name || '', name_en:item.name_en || '', artistic_name:item.artistic_name || '', artistic_name_en:item.artistic_name_en || '', email:item.email || '', city:item.city || '', city_en:item.city_en || '', bio:item.bio || '', bio_en:item.bio_en || '' }) }
  async function saveArtist() {
    if (!artist) return
    const target=artist; const snapshot=pageSnapshot(artists.data,target.id)
    setBusy(true)
    const form = new FormData(); Object.entries(draft).forEach(([key,value]) => form.set(key,value))
    try { const response=await api<Artist>(`/admin/artists/${target.id}/`, {method:'PATCH',body:form}); const updated:Artist={...response,...draft}; artists.setData(current=>setPaginatedItem(current,updated,{visible:artistVisible(updated),indexHint:snapshot.index})); toast.show('اطلاعات هنرمند ذخیره شد.','success'); setArtist(null); verifyArtistExact(updated,snapshot,true,{saved:true}) }
    catch(err){toast.show(errorMessageFa(err),'error')} finally{setBusy(false)}
  }
  async function verifyArtist(item: Artist) {
    if (item.verified || verifyingArtistId !== null) return
    const snapshot=pageSnapshot(artists.data,item.id)
    setVerifyingArtistId(item.id)
    const form = new FormData(); form.set('verified', 'true')
    try { const result=await api<Artist>(`/admin/artists/${item.id}/`, {method:'PATCH',body:form}); const updated={...item,...result,verified:true}; artists.setData(current=>setPaginatedItem(current,updated,{visible:artistVisible(updated),indexHint:snapshot.index})); toast.show('هنرمند تأیید شد.','success'); verifyArtistExact(updated,snapshot,true,{verified:true}) }
    catch(err){toast.show(errorMessageFa(err, 'تأیید هنرمند انجام نشد.'),'error')} finally{setVerifyingArtistId(null)}
  }
  async function review(status: 'accepted'|'rejected') {
    if (!application) return
    const target=application; const snapshot=pageSnapshot(pending.data,target.id)
    setBusy(true)
    try {
      const result=await api<ArtistAuth>(`/admin/pend_artists/${target.id}/`, {method:'PATCH',body:jsonBody({status,is_verified:status==='accepted'})}); const updated={...target,...result,status,is_verified:status==='accepted'}
      pending.setData(current=>removePaginatedItem(current,target.id))
      toast.show(status==='accepted'?'درخواست هنرمند تأیید شد.':'درخواست هنرمند رد شد.','success')
      setApplication(null)
      const syncClaimedArtist=(claimed:ArtistAuth['artist_claimed'])=>{
        if(status!=='accepted'||!claimed)return
        const artistId=Number(claimed);if(!Number.isFinite(artistId)||artistId<=0)return
        const artistSnapshot=pageSnapshot(artists.data,artistId)
        void verifyExactEntity<Artist>(`/admin/artists/${artistId}/`,{
          found:server=>artists.setData(current=>setPaginatedItem(current,server,{visible:artistSnapshot.index>=0&&artistVisible(server),indexHint:artistSnapshot.index})),
          missing:()=>artists.setData(current=>removePaginatedItem(current,artistId)),
        }).then(outcome=>{if(outcome!=='superseded')void artists.revalidate((current,incoming)=>reconcilePaginatedStable(current,incoming,artistSnapshot.order))})
      }
      syncClaimedArtist(updated.artist_claimed)
      void verifyExactEntity<ArtistAuth>(`/admin/pend_artists/${target.id}/`,{
        found:server=>{pending.setData(current=>setPaginatedItem(current,server,{visible:!['accepted','rejected'].includes(server.status),indexHint:snapshot.index}));syncClaimedArtist(server.artist_claimed)},
        missing:()=>pending.setData(current=>removePaginatedItem(current,target.id)),
      },{stopWhenFound:server=>server.status===status}).then(outcome=>{if(outcome!=='superseded')void pending.revalidate((current,incoming)=>reconcilePaginatedStable(current,incoming,snapshot.order))})
    } catch(err){toast.show(errorMessageFa(err),'error')} finally{setBusy(false)}
  }
  async function toggleBan() {
    if (!banTarget?.user) return
    const target=banTarget; const snapshot=pageSnapshot(artists.data,target.id); const nextBanned = !target.user_is_banned
    setBusy(true)
    try {
      await api('/admin/users/ban/', {method:'POST',body:jsonBody({user_id:target.user,banned:nextBanned})})
      const local={...target,user_is_banned:nextBanned}
      artists.setData(current=>setPaginatedItem(current,local))
      toast.show(nextBanned ? 'حساب مرتبط با هنرمند بدون حذف محتوا مسدود شد.' : 'مسدودی حساب هنرمند برداشته شد.','success')
      setBanTarget(null)
      verifyArtistExact(local,snapshot,true,{banned:nextBanned})
    } catch(err){toast.show(errorMessageFa(err),'error')} finally{setBusy(false)}
  }
  async function deleteArtist() {
    if (!deleteTarget) return
    const target=deleteTarget; const snapshot=pageSnapshot(artists.data,target.id)
    setBusy(true)
    try {
      await api(`/admin/artists/${target.id}/`, {method:'DELETE'})
      artists.setData(current=>removePaginatedItem(current,target.id))
      toast.show('پروفایل هنرمند حذف شد.','success')
      setDeleteTarget(null)
      verifyArtistExact(target,snapshot,true,{missing:true})
    } catch(err){toast.show(errorMessageFa(err, 'حذف هنرمند انجام نشد.'),'error')} finally{setBusy(false)}
  }

  const current = tab==='artists' ? artists : pending
  return <div className="page-stack">
    <PageHeader title="مدیریت هنرمندان" description="پروفایل هنرمندان و بررسی درخواست‌های احراز" />
    <div className="segmented">
      <button className={tab==='artists'?'is-active':''} onClick={()=>setTab('artists')}>هنرمندان</button>
      <button className={tab==='pending'?'is-active':''} onClick={()=>setTab('pending')}>درخواست‌های تأیید {pending.data?.count ? <span className="tab-count">{pending.data.count.toLocaleString('fa-IR')}</span> : null}</button>
    </div>
    {tab==='artists' && <Card className="toolbar-card"><SearchBox value={search} onChange={v=>{setSearch(v);setArtistPage(1)}} placeholder="نام هنرمند، شماره همراه یا ایمیل"/><div className="filters"><ProductSelect ariaLabel="فیلتر تأیید هنرمندان" value={verified} onValueChange={value=>{setVerified(value);setArtistPage(1)}} options={[{value:'',label:'همه هنرمندان'},{value:'true',label:'تأیید شده'},{value:'false',label:'تأیید نشده'}]}/></div></Card>}
    <Card>{current.error ? <ErrorState message={current.error} retry={()=>void current.reload()}/> : tab==='artists' ? <><DataTable<Artist> loading={artists.loading} rows={artists.data?.results || []} columns={[
      {key:'artist',title:'هنرمند',render:a=><div className="person-cell"><span className="avatar avatar--image">{a.profile_image?<img src={a.profile_image} alt="" loading="lazy"/>:(a.artistic_name||a.name)?.[0]}</span><div><strong>{a.artistic_name||a.name}</strong><span>{a.name}</span></div></div>},
      {key:'phone',title:'شماره همراه',render:a=><span dir="ltr">{a.user_phone||'—'}</span>},
      {key:'verify',title:'وضعیت',render:a=><div className="artist-status-cell">{a.verified?<span className="status status--success">تأیید شده</span>:<><span className="status status--neutral">تأیید نشده</span><button className="quick-verify" disabled={verifyingArtistId!==null} onClick={()=>void verifyArtist(a)} title="تأیید سریع هنرمند"><CheckCircle2 size={14}/>{verifyingArtistId===a.id?'در حال تأیید…':'تأیید سریع'}</button></>}</div>},
      {key:'created',title:'ایجاد',render:a=>dateTimeFa(a.created_at)},
      {key:'actions',title:'عملیات',render:a=><div className="row-actions"><button className="icon-button" onClick={()=>editArtist(a)} title="ویرایش"><Pencil size={17}/></button>{a.user&&<button className={`icon-button ${a.user_is_banned?'is-success':'is-danger'}`} onClick={()=>setBanTarget(a)} title={a.user_is_banned?'رفع مسدودی':'مسدودسازی امن'}>{a.user_is_banned?<Unlock size={17}/>:<Ban size={17}/>}</button>}<button className="icon-button is-danger" onClick={()=>setDeleteTarget(a)} title="حذف هنرمند"><Trash2 size={17}/></button></div>},
    ]}/>{artists.data&&<Pagination count={artists.data.count} page={artistPage} pageSize={20} onPage={setArtistPage}/>}</> : <><DataTable<ArtistAuth> loading={pending.loading} rows={pending.data?.results||[]} columns={[
      {key:'name',title:'درخواست‌دهنده',render:a=><div><strong>{a.stage_name||`${a.first_name||''} ${a.last_name||''}`.trim()||'بدون نام'}</strong><div className="subline" dir="ltr">{a.phone_number||'—'}</div></div>},
      {key:'type',title:'نوع درخواست',render:a=>a.auth_type==='existing_artist'?'اتصال به هنرمند موجود':'هنرمند جدید'},
      {key:'status',title:'وضعیت',render:a=><StatusBadge value={a.status}/>} ,
      {key:'created',title:'ثبت',render:a=>dateTimeFa(a.created_at)},
      {key:'action',title:'بررسی',render:a=><button className="button button--compact" onClick={()=>setApplication(a)}><Eye size={16}/> مشاهده</button>},
    ]}/>{pending.data&&<Pagination count={pending.data.count} page={pendingPage} pageSize={20} onPage={setPendingPage}/>}</>}</Card>
    <Modal open={Boolean(artist)} title="ویرایش هنرمند" onClose={()=>setArtist(null)} wide>{artist&&<div className="form-grid"><Field label="نام"><input value={draft.name||''} onChange={e=>setDraft({...draft,name:e.target.value})}/></Field><Field label="معادل انگلیسی نام"><input dir="ltr" value={draft.name_en||''} onChange={e=>setDraft({...draft,name_en:e.target.value})}/></Field><Field label="نام هنری"><input value={draft.artistic_name||''} onChange={e=>setDraft({...draft,artistic_name:e.target.value})}/></Field><Field label="معادل انگلیسی نام هنری"><input dir="ltr" value={draft.artistic_name_en||''} onChange={e=>setDraft({...draft,artistic_name_en:e.target.value})}/></Field><Field label="ایمیل"><input dir="ltr" value={draft.email||''} onChange={e=>setDraft({...draft,email:e.target.value})}/></Field><Field label="شهر"><input value={draft.city||''} onChange={e=>setDraft({...draft,city:e.target.value})}/></Field><Field label="معادل انگلیسی شهر"><input dir="ltr" value={draft.city_en||''} onChange={e=>setDraft({...draft,city_en:e.target.value})}/></Field><Field label="زندگی‌نامه"><textarea value={draft.bio||''} onChange={e=>setDraft({...draft,bio:e.target.value})}/></Field><Field label="معادل انگلیسی زندگی‌نامه"><textarea dir="ltr" value={draft.bio_en||''} onChange={e=>setDraft({...draft,bio_en:e.target.value})}/></Field><div className="dialog-actions form-grid__full"><button className="button button--ghost" onClick={()=>setArtist(null)}>انصراف</button><button className="button button--primary" disabled={busy} onClick={saveArtist}><ShieldCheck size={17}/>ذخیره</button></div></div>}</Modal>
    <Modal open={Boolean(application)} title="بررسی درخواست هنرمند" onClose={()=>setApplication(null)} wide>{application&&<div className="application-detail"><div className="identity-grid"><div><span>نام و نام خانوادگی</span><strong>{`${application.first_name||''} ${application.last_name||''}`.trim()||'—'}</strong></div><div><span>نام هنری</span><strong>{application.stage_name||'—'}</strong></div><div><span>شماره همراه</span><strong dir="ltr">{application.phone_number||'—'}</strong></div><div><span>کد ملی</span><strong>{application.national_id||'—'}</strong></div><div><span>ایمیل</span><strong dir="ltr">{application.email||'—'}</strong></div><div><span>شهر</span><strong>{application.city||'—'}</strong></div></div>{application.biography&&<div className="detail-block"><span>زندگی‌نامه</span><p>{application.biography}</p></div>}<div className="document-grid">{application.profile_image&&<a href={application.profile_image} target="_blank" rel="noreferrer"><img src={application.profile_image} alt="تصویر پروفایل"/><span>تصویر پروفایل</span></a>}{application.national_id_image&&<a href={application.national_id_image} target="_blank" rel="noreferrer"><img src={application.national_id_image} alt="تصویر مدرک هویتی"/><span>مدرک هویتی</span></a>}</div><div className="dialog-actions"><button className="button button--danger" disabled={busy} onClick={()=>review('rejected')}><XCircle size={17}/>رد درخواست</button><button className="button button--primary" disabled={busy} onClick={()=>review('accepted')}><CheckCircle2 size={17}/>تأیید هنرمند</button></div></div>}</Modal>
    <Confirm open={Boolean(banTarget)} title={banTarget?.user_is_banned?'رفع مسدودی حساب':'مسدودسازی حساب'} text={banTarget?.user_is_banned?'دسترسی حساب مرتبط با این هنرمند دوباره فعال شود؟':'حساب مرتبط با این هنرمند مسدود می‌شود، اما پروفایل و محتوای منتشرشده برای حفظ یکپارچگی داده حذف نخواهد شد.'} confirmLabel={banTarget?.user_is_banned?'رفع مسدودی':'مسدود کردن'} danger={!banTarget?.user_is_banned} busy={busy} onConfirm={toggleBan} onClose={()=>setBanTarget(null)}/>
    <Confirm open={Boolean(deleteTarget)} title="حذف دائمی هنرمند" text="این عملیات فقط برای پروفایل هنرمندی که هیچ آهنگ، آلبوم، انتشار یا سابقه تسویه وابسته ندارد مجاز است. در غیر این صورت سرور برای حفاظت از اطلاعات، حذف را متوقف می‌کند." confirmLabel="حذف دائمی" danger busy={busy} onConfirm={deleteArtist} onClose={()=>setDeleteTarget(null)}/>
  </div>
}
