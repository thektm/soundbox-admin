import { useCallback, useEffect, useRef, useState, type Dispatch, type SetStateAction } from 'react'
import { api, errorMessageFa } from './api'

export function useRemote<T>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(Boolean(path))
  const [error, setError] = useState('')
  const requestId = useRef(0)
  const silentRequestId = useRef(0)
  const pathRef = useRef<string | null>(path)
  pathRef.current = path

  const setCurrentData = useCallback<Dispatch<SetStateAction<T | null>>>((value) => {
    if (pathRef.current !== path) return
    ++silentRequestId.current
    setData(value)
  }, [path])

  const reload = useCallback(async () => {
    if (!path) { setLoading(false); return null }
    const id = ++requestId.current
    ++silentRequestId.current
    setLoading(true); setError('')
    try {
      const result = await api<T>(path)
      if (pathRef.current === path && id === requestId.current) setData(result)
      return result
    } catch (err) {
      if (pathRef.current === path && id === requestId.current) setError(errorMessageFa(err))
      return null
    } finally {
      if (pathRef.current === path && id === requestId.current) setLoading(false)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps])

  const revalidate = useCallback(async (merge?: (current: T | null, incoming: T) => T) => {
    if (!path || pathRef.current !== path) return null
    const visibleGeneration = requestId.current
    const silentId = ++silentRequestId.current
    try {
      const result = await api<T>(path)
      if (pathRef.current === path && visibleGeneration === requestId.current && silentId === silentRequestId.current) {
        setData(current => merge ? merge(current, result) : result)
      }
      return result
    } catch {
      return null
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps])

  useEffect(() => { void reload() }, [reload])
  return { data, setData:setCurrentData, loading, error, reload, revalidate }
}
