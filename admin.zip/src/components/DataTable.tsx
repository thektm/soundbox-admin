import type { ReactNode } from 'react'
import { Empty, Loading } from './Ui'

type Column<T> = { key: string; title: string; render: (item: T) => ReactNode; className?: string }
export function DataTable<T>({ rows, columns, loading, emptyTitle }: { rows: T[]; columns: Column<T>[]; loading?: boolean; emptyTitle?: string }) {
  if (loading) return <Loading />
  if (!rows.length) return <Empty title={emptyTitle} />
  return <div className="table-wrap"><table className="data-table"><thead><tr>{columns.map(column => <th key={column.key} className={column.className}>{column.title}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={(row as { id?: string | number }).id ?? index}>{columns.map(column => <td key={column.key} className={column.className}>{column.render(row)}</td>)}</tr>)}</tbody></table></div>
}
