import { useState } from 'react'
import { Eye, EyeOff, Heart, Pencil, Play, Trash2 } from 'lucide-react'
import { DataTable } from '../components/DataTable'
import { Card, Confirm, ErrorState, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { SongMetadataModal } from '../components/SongMetadataModal'
import { MarqueeText } from '../components/MarqueeText'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, queryString } from '../lib/api'
import { useDebouncedValue } from '../lib/hooks'
import { dateTimeFa, numberFa } from '../lib/format'
import type { Paginated, Song } from '../lib/types'
import { useRemote } from '../lib/useRemote'

const featureLabels: Array<[keyof Song, string]> = [
  ['tempo','تمپو'], ['energy','انرژی'], ['danceability','رقص‌پذیری'], ['valence','حس مثبت'],
  ['acousticness','آکوستیک'], ['instrumentalness','بی‌کلام'], ['speechiness','گفتاری'],
]

function Tags({ values }: { values?: string[] }) {
  return values?.length ? <div className="tag-row">{values.map(value => <span key={value}>{value}</span>)}</div> : <span className="muted">ثبت نشده</span>
}

function MetaMeter({ value = 0, onClick }: { value?: number; onClick:()=>void }) {
  const safe=Math.max(0,Math.min(100,value))
  return <button type="button" className="meta-meter meta-meter--action" onClick={onClick} title="تکمیل و ویرایش متادیتای الگوریتم" aria-label={`ویرایش متادیتای الگوریتم؛ ${value} درصد تکمیل شده`}>
    <div><span>تکمیل متادیتا</span><strong>{numberFa(value)}٪</strong></div>
    <div className="meta-meter__bar" aria-hidden="true"><i style={{ width:`${safe}%` }} /></div>
  </button>
}

export default function SongsPage(){
  const [search,setSearch]=useState(''); const [status,setStatus]=useState('all'); const [sort,setSort]=useState('time'); const [direction,setDirection]=useState('desc'); const [page,setPage]=useState(1)
  const [selected,setSelected]=useState<Song|null>(null); const [detailLoading,setDetailLoading]=useState(false); const [edit,setEdit]=useState<{song:Song;page:1|2|3}|null>(null)
  const [remove,setRemove]=useState<{song:Song;mode:'soft'|'hard'}|null>(null); const [removing,setRemoving]=useState(false)
  const q=useDebouncedValue(search); const toast=useToast(); const path='/admin/songs/'+queryString({q,status,sort,direction,page,page_size:20}); const remote=useRemote<Paginated<Song>>(path,[q,status,sort,direction,page])
  async function detail(song:Song){setSelected(song);setDetailLoading(true);try{setSelected(await api<Song>(`/admin/songs/${song.id}/`))}catch(err){toast.show(errorMessageFa(err),'error')}finally{setDetailLoading(false)}}
  async function removeSong(){
    if(!remove)return
    setRemoving(true)
    try{
      await api(`/admin/songs/${remove.song.id}/?mode=${remove.mode}`,{method:'DELETE'})
      toast.show(remove.mode==='soft'?'آهنگ بدون حذف اطلاعات از دسترس مخاطبان خارج شد.':'آهنگ برای همیشه از پایگاه داده حذف شد.','success')
      if(selected?.id===remove.song.id)setSelected(null)
      if(edit?.song.id===remove.song.id)setEdit(null)
      setRemove(null)
      await remote.reload()
    }catch(err){toast.show(errorMessageFa(err),'error')}finally{setRemoving(false)}
  }
  function openMeta(song:Song){setEdit({song,page:1})}
  function openEdit(song:Song){setEdit({song,page:3})}
  return <div className="page-stack"><PageHeader title="مدیریت آهنگ‌ها" description="مشاهده وضعیت، آمار پخش و متادیتای مؤثر بر الگوریتم پیشنهاد"/>
    <Card className="toolbar-card"><SearchBox value={search} onChange={v=>{setSearch(v);setPage(1)}} placeholder="نام آهنگ یا هنرمند"/><div className="filters"><select value={status} onChange={e=>{setStatus(e.target.value);setPage(1)}}><option value="all">همه وضعیت‌ها</option><option value="published">منتشر شده</option><option value="pending">در انتظار</option><option value="approved">تأیید شده</option><option value="rejected">رد شده</option><option value="deleted">از دسترس خارج</option></select><select value={`${sort}:${direction}`} onChange={e=>{const[s,d]=e.target.value.split(':');setSort(s);setDirection(d);setPage(1)}}><option value="time:desc">جدیدترین</option><option value="plays:desc">بیشترین پخش</option><option value="plays:asc">کمترین پخش</option><option value="likes:desc">بیشترین پسند</option><option value="likes:asc">کمترین پسند</option><option value="meta:desc">متادیتای کامل‌تر</option><option value="meta:asc">متادیتای ناقص‌تر</option><option value="release:desc">تاریخ انتشار</option></select></div></Card>
    <Card>{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<><DataTable<Song> loading={remote.loading} rows={remote.data?.results||[]} columns={[
      {key:'song',title:'آهنگ',render:s=><div className="media-cell"><span className="media-cover">{s.cover_image?<img src={s.cover_image} alt="" loading="lazy"/>:<Play size={18}/>}</span><div><MarqueeText as="strong" text={s.title}/><MarqueeText text={s.artist_name}/></div></div>},
      {key:'status',title:'وضعیت',render:s=><StatusBadge value={s.status}/>},{key:'plays',title:'پخش',render:s=>numberFa(s.plays)},{key:'likes',title:'پسند',render:s=><span className="inline-icon"><Heart size={14}/>{numberFa(s.likes_count||0)}</span>},
      {key:'meta',title:'متادیتای الگوریتم',render:s=><MetaMeter value={s.metadata_completion||0} onClick={()=>openMeta(s)}/>},{key:'created',title:'ثبت',render:s=>dateTimeFa(s.created_at)},
      {key:'actions',title:'عملیات',render:s=><div className="row-actions"><button className="icon-button" title="جزئیات" onClick={()=>void detail(s)}><Eye size={17}/></button><button className="icon-button" title="ویرایش" onClick={()=>openEdit(s)}><Pencil size={17}/></button>{s.status!=='deleted'&&<button className="icon-button icon-button--warning" title="حذف امن؛ فقط خارج از دسترس" onClick={()=>setRemove({song:s,mode:'soft'})}><EyeOff size={17}/></button>}<button className="icon-button icon-button--danger" title="حذف دائمی از دیتابیس" onClick={()=>setRemove({song:s,mode:'hard'})}><Trash2 size={17}/></button></div>},
    ]}/>{remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}</>}</Card>
    <Modal open={Boolean(selected)} title="جزئیات آهنگ" onClose={()=>setSelected(null)} wide>{selected&&<div className="song-detail"><div className="song-detail__head"><span className="media-cover media-cover--xl">{selected.cover_image?<img src={selected.cover_image} alt=""/>:<Play size={26}/>}</span><div className="song-detail__identity"><MarqueeText as="strong" className="song-detail__title" text={selected.title}/><MarqueeText className="song-detail__artist" text={selected.artist_name}/><StatusBadge value={selected.status}/></div></div>{detailLoading&&<div className="inline-note">در حال تکمیل جزئیات…</div>}<div className="identity-grid"><div><span>تعداد پخش</span><strong>{numberFa(selected.plays)}</strong></div><div><span>تعداد پسند</span><strong>{numberFa(selected.likes_count||0)}</strong></div><div><span>آلبوم</span><strong>{selected.album_title||'تک‌آهنگ'}</strong></div><div><span>تاریخ انتشار</span><strong>{selected.release_date||'—'}</strong></div><div><span>مدت</span><strong>{selected.duration_seconds?`${numberFa(selected.duration_seconds)} ثانیه`:'—'}</strong></div><div><span>تکمیل متادیتای الگوریتم</span><strong>{numberFa(selected.metadata_completion||0)}٪</strong></div></div><div className="classification-grid"><div><span>ژانر</span><Tags values={selected.genre_names}/></div><div><span>زیرژانر</span><Tags values={selected.sub_genre_names}/></div><div><span>مود</span><Tags values={selected.mood_names}/></div></div><div className="audio-feature-grid">{featureLabels.map(([key,label])=><div key={String(key)}><span>{label}</span><strong>{selected[key] == null ? '—' : numberFa(Number(selected[key]))}</strong></div>)}</div>{selected.audio_file&&<audio className="audio-preview" src={selected.converted_audio_url||selected.audio_file} controls preload="none"/>}<div className="dialog-actions song-detail__actions">{selected.status!=='deleted'&&<button className="button button--ghost button--warning" onClick={()=>setRemove({song:selected,mode:'soft'})}><EyeOff size={16}/>حذف امن</button>}<button className="button button--danger" onClick={()=>setRemove({song:selected,mode:'hard'})}><Trash2 size={16}/>حذف دائمی</button></div></div>}</Modal>
    <Confirm open={Boolean(remove)} title={remove?.mode==='soft'?'حذف امن آهنگ':'حذف دائمی آهنگ'} text={remove?.mode==='soft'?'رکورد، آمار پخش، درآمد و ارتباطات آهنگ حفظ می‌شود؛ فقط آهنگ از دسترس مخاطبان خارج خواهد شد.':'این عملیات رکورد آهنگ را از پایگاه داده حذف می‌کند و برگشت‌پذیر نیست. ارتباط آن با انتشارها نیز به‌صورت امن پاک‌سازی می‌شود.'} confirmLabel={remove?.mode==='soft'?'خارج کردن از دسترس':'حذف دائمی'} danger={remove?.mode==='hard'} busy={removing} onClose={()=>setRemove(null)} onConfirm={()=>void removeSong()}/>
    <SongMetadataModal song={edit?.song||null} initialPage={edit?.page||1} onClose={()=>setEdit(null)} onSaved={async()=>{await remote.reload()}} onRemoved={async()=>{setEdit(null);await remote.reload()}}/>
  </div>
}
