import { useState, type ReactNode } from 'react'
import { LayoutGrid, ListMusic, Music2, Pencil, Plus, Trash2 } from 'lucide-react'
import { PlaylistBuilder, type PlaylistRecord } from '../components/PlaylistBuilder'
import { SearchSectionsPanel } from '../components/SearchSectionsPanel'
import { TimeOfDayPlaylistsPanel } from '../components/TimeOfDayPlaylistsPanel'
import { DataTable } from '../components/DataTable'
import { Card, Confirm, ErrorState, PageHeader, Pagination } from '../components/Ui'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, queryString } from '../lib/api'
import { dateTimeFa, numberFa } from '../lib/format'
import type { Paginated } from '../lib/types'
import { useRemote } from '../lib/useRemote'

type Tab = 'playlists' | 'sections'
type DeleteTarget = { id:number; title:string } | null

function TabButton({ active, onClick, icon, children }:{active:boolean;onClick:()=>void;icon:ReactNode;children:ReactNode}) {
  return <button className={active ? 'content-tab is-active' : 'content-tab'} onClick={onClick}>{icon}<span>{children}</span></button>
}

export default function PlaylistsSectionsPage() {
  const [tab, setTab] = useState<Tab>('playlists')
  return <div className="page-stack">
    <PageHeader title="پلی‌لیست‌ها و بخش‌ها" description="ساخت پلی‌لیست‌های رسمی و مدیریت بخش‌های صفحه جستجو" />
    <div className="content-tabs" role="tablist" aria-label="پلی‌لیست‌ها و بخش‌های جستجو">
      <TabButton active={tab==='playlists'} onClick={()=>setTab('playlists')} icon={<ListMusic size={18}/>}>پلی‌لیست‌ها</TabButton>
      <TabButton active={tab==='sections'} onClick={()=>setTab('sections')} icon={<LayoutGrid size={18}/>}>بخش‌های جستجو</TabButton>
    </div>
    {tab==='playlists' ? <PlaylistsPanel/> : <SearchSectionsPanel/>}
  </div>
}

function PlaylistsPanel(){
  const toast=useToast()
  const [page,setPage]=useState(1)
  const [open,setOpen]=useState(false)
  const [editing,setEditing]=useState<PlaylistRecord|null>(null)
  const [busy,setBusy]=useState(false)
  const [del,setDel]=useState<DeleteTarget>(null)
  const remote=useRemote<Paginated<PlaylistRecord>>('/admin/playlists/'+queryString({page,page_size:20}),[page])

  async function remove(){
    if(!del)return
    setBusy(true)
    try{
      await api(`/admin/playlists/${del.id}/`,{method:'DELETE'})
      toast.show('پلی‌لیست حذف شد.','success')
      setDel(null)
      await remote.reload()
    }catch(e){toast.show(errorMessageFa(e),'error')}finally{setBusy(false)}
  }

  return <>
    <TimeOfDayPlaylistsPanel/>
    <div className="section-actions">
      <div><strong>پلی‌لیست‌های رسمی</strong><span>مجموعه‌های منتخب ادمین برای نمایش در پلتفرم</span></div>
      <button className="button button--primary" onClick={()=>{setEditing(null);setOpen(true)}}><Plus size={17}/>پلی‌لیست جدید</button>
    </div>
    <Card>{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<>
      <DataTable<PlaylistRecord> loading={remote.loading} rows={remote.data?.results||[]} emptyTitle="پلی‌لیستی ثبت نشده است" columns={[
        {key:'name',title:'پلی‌لیست',render:x=><div className="media-cell">{x.cover_image?<img src={x.cover_image} alt="" loading="lazy"/>:<div className="media-placeholder"><Music2 size={18}/></div>}<div><strong>{x.title}</strong><span>{numberFa(x.songs?.length||0)} آهنگ</span></div></div>},
        {key:'engagement',title:'تعامل',render:x=><div className="stacked-text"><span>{numberFa(x.likes_count)} پسند</span><small>{numberFa(x.saves_count)} ذخیره</small></div>},
        {key:'created',title:'ایجاد',render:x=>dateTimeFa(x.created_at)},
        {key:'actions',title:'عملیات',render:x=><div className="row-actions"><button className="icon-button" onClick={()=>{setEditing(x);setOpen(true)}} aria-label="ویرایش پلی‌لیست"><Pencil size={16}/></button><button className="icon-button icon-button--danger" onClick={()=>setDel({id:x.id,title:x.title})} aria-label="حذف پلی‌لیست"><Trash2 size={16}/></button></div>}
      ]}/>
      {remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}
    </>}</Card>
    <PlaylistBuilder open={open} item={editing} onClose={()=>setOpen(false)} onSaved={async()=>{setOpen(false);await remote.reload()}}/>
    <Confirm open={Boolean(del)} title="حذف پلی‌لیست" text={`پلی‌لیست «${del?.title||''}» حذف شود؟`} confirmLabel="حذف" danger busy={busy} onClose={()=>setDel(null)} onConfirm={()=>void remove()}/>
  </>
}
