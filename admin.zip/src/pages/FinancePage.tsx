import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { CheckCircle2, CircleDollarSign, Eye, ReceiptText, Save, WalletCards } from 'lucide-react'
import { DataTable } from '../components/DataTable'
import { Card, ErrorState, Field, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, jsonBody, queryString } from '../lib/api'
import { useDebouncedValue } from '../lib/hooks'
import { dateTimeFa, moneyFa, numberFa, paymentMethodFa } from '../lib/format'
import type { DepositRequest, Paginated, PaymentTransaction } from '../lib/types'
import { useRemote } from '../lib/useRemote'

type Period = {
  revenue:number; successful_payment_count:number; paid_to_artists:number; paid_to_artists_count:number
  pending_artist_payouts:number; pending_artist_payout_count:number
}
type FinanceSummary = { today:Period; last_7_days:Period; last_30_days:Period; all_time:Period; payment_status:Record<string,number>; payout_status:Record<string,number> }
type ArtistEarning = {
  artist_id:number; artist_name:string; artist_phone?:string|null; verified:boolean; stream_count:number
  earned_total:number; paid_total:number; pending_total:number; remaining_total:number
}
type FinanceTab = 'payments' | 'payouts' | 'earnings'

export default function FinancePage() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const initialTab: FinanceTab = params.get('tab') === 'payouts' || params.get('tab') === 'earnings' ? params.get('tab') as FinanceTab : 'payments'
  const [tab, setTab] = useState<FinanceTab>(initialTab)
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState(() => params.get('status') || '')
  const [sort, setSort] = useState(initialTab === 'earnings' ? 'earned' : 'time')
  const [direction, setDirection] = useState('desc')
  const [page, setPage] = useState(1)
  const [selectedPayment, setSelectedPayment] = useState<PaymentTransaction|null>(null)
  const [selectedPayout, setSelectedPayout] = useState<DepositRequest|null>(null)
  const [payoutStatus, setPayoutStatus] = useState('')
  const [transactionId, setTransactionId] = useState('')
  const [busy, setBusy] = useState(false)
  const q = useDebouncedValue(search)
  const toast = useToast()
  const summary = useRemote<FinanceSummary>('/admin/finance/')
  const payments = useRemote<Paginated<PaymentTransaction>>(
    tab === 'payments' ? '/admin/finance/transactions/' + queryString({ q, status, sort, direction, page, page_size:20 }) : null,
    [q, status, sort, direction, page, tab],
  )
  const payouts = useRemote<Paginated<DepositRequest>>(
    tab === 'payouts' ? '/admin/finance/deposits/' + queryString({ q, status, sort, direction, page, page_size:20 }) : null,
    [q, status, sort, direction, page, tab],
  )
  const earnings = useRemote<Paginated<ArtistEarning>>(
    tab === 'earnings' ? '/admin/finance/artist-earnings/' + queryString({ q, sort, direction, page, page_size:20 }) : null,
    [q, sort, direction, page, tab],
  )
  const current = tab === 'payments' ? payments : tab === 'payouts' ? payouts : earnings

  function switchTab(next: FinanceTab) {
    setTab(next); setSearch(''); setStatus(''); setPage(1); setDirection('desc'); setSort(next === 'earnings' ? 'earned' : 'time')
  }
  function openPayout(payout: DepositRequest) {
    setSelectedPayout(payout); setPayoutStatus(payout.status); setTransactionId(payout.transaction_id || '')
  }
  async function savePayout() {
    if (!selectedPayout) return
    setBusy(true)
    try {
      const result = await api<DepositRequest>(`/admin/finance/deposits/${selectedPayout.id}/`, { method:'PATCH', body:jsonBody({ status:payoutStatus, transaction_id:transactionId }) })
      setSelectedPayout(result)
      toast.show('وضعیت تسویه به‌روزرسانی شد.', 'success')
      await payouts.reload(); await summary.reload()
    } catch (err) { toast.show(errorMessageFa(err), 'error') } finally { setBusy(false) }
  }

  const all = summary.data?.all_time
  return <div className="page-stack">
    <PageHeader title="مالی و تسویه" description="پرداخت کاربران، تعهد مالی هنرمندان و چرخه کامل تسویه" />
    {all && <div className="finance-stats">
      <Card><CircleDollarSign size={20}/><span>کل درآمد پلتفرم</span><strong>{moneyFa(all.revenue)}</strong><small>{numberFa(all.successful_payment_count)} پرداخت موفق</small></Card>
      <Card><CheckCircle2 size={20}/><span>پرداخت‌شده به هنرمندان</span><strong>{moneyFa(all.paid_to_artists)}</strong><small>{numberFa(all.paid_to_artists_count)} تسویه تکمیل‌شده</small></Card>
      <Card><WalletCards size={20}/><span>در انتظار تسویه</span><strong>{moneyFa(all.pending_artist_payouts)}</strong><small>{numberFa(all.pending_artist_payout_count)} درخواست باز</small></Card>
    </div>}

    <div className="segmented">
      <button className={tab==='payments'?'is-active':''} onClick={()=>switchTab('payments')}>پرداخت کاربران</button>
      <button className={tab==='payouts'?'is-active':''} onClick={()=>switchTab('payouts')}>تسویه هنرمندان</button>
      <button className={tab==='earnings'?'is-active':''} onClick={()=>switchTab('earnings')}>درآمد هنرمندان</button>
    </div>

    <Card className="toolbar-card">
      <SearchBox value={search} onChange={value=>{setSearch(value);setPage(1)}} placeholder={tab==='payments'?'شماره تراکنش یا شماره همراه':tab==='payouts'?'نام هنرمند یا شماره تراکنش':'نام هنرمند یا شماره همراه'} />
      <div className="filters">
        {tab !== 'earnings' && <select value={status} onChange={e=>{setStatus(e.target.value);setPage(1)}}>
          {tab==='payments' ? <><option value="">همه وضعیت‌ها</option><option value="success">موفق</option><option value="pending">در انتظار</option><option value="failed">ناموفق</option></> : <><option value="">همه وضعیت‌ها</option><option value="open">در انتظار تسویه</option><option value="pending">در انتظار</option><option value="approved">تأیید شده</option><option value="done">انجام شده</option><option value="rejected">رد شده</option></>}
        </select>}
        <select value={`${sort}:${direction}`} onChange={e=>{const [s,d]=e.target.value.split(':');setSort(s);setDirection(d);setPage(1)}}>
          {tab==='earnings' ? <><option value="earned:desc">بیشترین درآمد</option><option value="earned:asc">کمترین درآمد</option><option value="streams:desc">بیشترین استریم</option><option value="streams:asc">کمترین استریم</option></> : <><option value="time:desc">جدیدترین</option><option value="time:asc">قدیمی‌ترین</option><option value="amount:desc">بیشترین مبلغ</option><option value="amount:asc">کمترین مبلغ</option></>}
        </select>
      </div>
    </Card>

    <Card>{current.error ? <ErrorState message={current.error} retry={()=>void current.reload()} /> : tab === 'payments' ? <>
      <DataTable<PaymentTransaction> loading={payments.loading} rows={payments.data?.results || []} columns={[
        {key:'id',title:'شناسه تراکنش',render:x=><code className="mono">{x.transaction_id}</code>},
        {key:'user',title:'کاربر',render:x=><span dir="ltr">{x.user_phone}</span>},
        {key:'amount',title:'مبلغ',render:x=><strong>{moneyFa(x.amount)}</strong>},
        {key:'status',title:'وضعیت',render:x=><StatusBadge value={x.status}/>},
        {key:'time',title:'زمان',render:x=>dateTimeFa(x.created_at)},
        {key:'action',title:'جزئیات',render:x=><button className="icon-button" onClick={()=>setSelectedPayment(x)} title="جزئیات"><Eye size={17}/></button>},
      ]}/>
      {payments.data && <><div className="table-summary"><span>جمع نتایج فیلترشده</span><strong>{moneyFa(payments.data.total_amount)}</strong></div><Pagination count={payments.data.count} page={page} pageSize={20} onPage={setPage}/></>}
    </> : tab === 'payouts' ? <>
      <DataTable<DepositRequest> loading={payouts.loading} rows={payouts.data?.results || []} columns={[
        {key:'artist',title:'هنرمند',render:x=><div><strong>{x.artist_name}</strong><div className="subline" dir="ltr">{x.artist_phone||'—'}</div></div>},
        {key:'amount',title:'مبلغ',render:x=><strong>{moneyFa(x.amount)}</strong>},
        {key:'status',title:'وضعیت',render:x=><StatusBadge value={x.status}/>},
        {key:'time',title:'ثبت درخواست',render:x=>dateTimeFa(x.submission_date)},
        {key:'action',title:'مدیریت',render:x=><button className="button button--compact" onClick={()=>openPayout(x)}><Eye size={16}/>بررسی</button>},
      ]}/>
      {payouts.data && <><div className="table-summary"><span>جمع درخواست‌های فیلترشده</span><strong>{moneyFa(payouts.data.total_amount)}</strong></div><Pagination count={payouts.data.count} page={page} pageSize={20} onPage={setPage}/></>}
    </> : <>
      <DataTable<ArtistEarning> loading={earnings.loading} rows={earnings.data?.results || []} columns={[
        {key:'artist',title:'هنرمند',render:x=><div><strong>{x.artist_name}</strong><div className="subline" dir="ltr">{x.artist_phone||'—'}</div></div>},
        {key:'verify',title:'وضعیت',render:x=><StatusBadge value={x.verified?'accepted':'pending'}/>},
        {key:'streams',title:'استریم',render:x=><strong>{numberFa(x.stream_count)}</strong>},
        {key:'earned',title:'درآمد ثبت‌شده',render:x=><strong>{moneyFa(x.earned_total)}</strong>},
        {key:'paid',title:'تسویه‌شده',render:x=>moneyFa(x.paid_total)},
        {key:'pending',title:'در صف تسویه',render:x=>moneyFa(x.pending_total)},
        {key:'remaining',title:'مانده قابل رهگیری',render:x=><strong>{moneyFa(x.remaining_total)}</strong>},
        {key:'action',title:'عملیات',render:x=><button className="button button--compact" onClick={()=>navigate(`/artists?q=${encodeURIComponent(x.artist_phone || x.artist_name)}`)}><Eye size={16}/>هنرمند</button>},
      ]}/>
      {earnings.data && <><div className="table-summary"><span>کل درآمد ثبت‌شده نتایج</span><strong>{moneyFa(earnings.data.total_amount)}</strong></div><Pagination count={earnings.data.count} page={page} pageSize={20} onPage={setPage}/></>}
    </>}</Card>

    <Modal open={Boolean(selectedPayment)} title="جزئیات پرداخت کاربر" onClose={()=>setSelectedPayment(null)}>{selectedPayment && <div className="receipt">
      <div className="receipt__icon"><ReceiptText size={24}/></div><div><span>شناسه تراکنش</span><strong className="mono">{selectedPayment.transaction_id}</strong></div><div><span>شماره همراه</span><strong dir="ltr">{selectedPayment.user_phone}</strong></div><div><span>مبلغ</span><strong>{moneyFa(selectedPayment.amount)}</strong></div><div><span>روش پرداخت</span><strong>{paymentMethodFa(selectedPayment.payment_method)}</strong></div><div><span>وضعیت</span><StatusBadge value={selectedPayment.status}/></div><div><span>زمان ثبت</span><strong>{dateTimeFa(selectedPayment.created_at)}</strong></div>
    </div>}</Modal>

    <Modal open={Boolean(selectedPayout)} title="مدیریت تسویه هنرمند" onClose={()=>setSelectedPayout(null)}>{selectedPayout && <div className="form-grid">
      <div className="payout-amount form-grid__full"><span>مبلغ درخواست</span><strong>{moneyFa(selectedPayout.amount)}</strong><small>{selectedPayout.artist_name}</small></div>
      <Field label="وضعیت تسویه"><select value={payoutStatus} onChange={e=>setPayoutStatus(e.target.value)}><option value="pending">در انتظار</option><option value="approved">تأیید شده</option><option value="rejected">رد شده</option><option value="done">انجام شده</option></select></Field>
      <Field label="شماره تراکنش" hint={payoutStatus==='done'?'برای ثبت وضعیت انجام‌شده الزامی است.':'در زمان پرداخت نهایی ثبت کنید.'}><input dir="ltr" value={transactionId} onChange={e=>setTransactionId(e.target.value)}/></Field>
      <div className="dialog-actions form-grid__full"><button className="button button--ghost" onClick={()=>setSelectedPayout(null)}>بستن</button><button className="button button--primary" disabled={busy} onClick={()=>void savePayout()}><Save size={17}/>ذخیره وضعیت</button></div>
    </div>}</Modal>
  </div>
}
