import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Ban, Check, Pencil, ShieldCheck, Unlock } from 'lucide-react'
import { DataTable } from '../components/DataTable'
import { Card, Confirm, ErrorState, Field, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, jsonBody, queryString } from '../lib/api'
import { useDebouncedValue } from '../lib/hooks'
import { dateTimeFa } from '../lib/format'
import type { AdminUser, Paginated } from '../lib/types'
import { useRemote } from '../lib/useRemote'

export default function UsersPage() {
  const [params] = useSearchParams()
  const [search, setSearch] = useState(() => params.get('q') || '')
  const [state, setState] = useState(() => params.get('state') || '')
  const [plan, setPlan] = useState(() => params.get('plan') || '')
  const [sort, setSort] = useState('time')
  const [direction, setDirection] = useState('desc')
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState<AdminUser | null>(null)
  const [banTarget, setBanTarget] = useState<AdminUser | null>(null)
  const [busy, setBusy] = useState(false)
  const q = useDebouncedValue(search)
  const toast = useToast()
  const path = '/admin/users/' + queryString({ role:'audience', q, state, plan, sort, direction, page, page_size:20 })
  const remote = useRemote<Paginated<AdminUser>>(path, [q, state, plan, sort, direction, page])
  const rows = remote.data?.results || []

  const [draft, setDraft] = useState<{first_name:string;last_name:string;email:string;stream_quality:string} | null>(null)
  function openEdit(user: AdminUser) { setSelected(user); setDraft({ first_name:user.first_name || '', last_name:user.last_name || '', email:user.email || '', stream_quality:user.stream_quality }) }
  async function saveEdit() {
    if (!selected || !draft) return
    setBusy(true)
    try { await api(`/admin/users/${selected.id}/`, { method:'PATCH', body:jsonBody(draft) }); toast.show('اطلاعات کاربر ذخیره شد.', 'success'); setSelected(null); await remote.reload() }
    catch (err) { toast.show(errorMessageFa(err), 'error') } finally { setBusy(false) }
  }
  async function toggleBan() {
    if (!banTarget) return
    setBusy(true)
    try { await api('/admin/users/ban/', { method:'POST', body:jsonBody({ user_id:banTarget.id, banned:!banTarget.is_banned }) }); toast.show(banTarget.is_banned ? 'مسدودی کاربر برداشته شد.' : 'کاربر بدون حذف اطلاعات مسدود شد.', 'success'); setBanTarget(null); await remote.reload() }
    catch (err) { toast.show(errorMessageFa(err), 'error') } finally { setBusy(false) }
  }

  return <div className="page-stack">
    <PageHeader title="مدیریت کاربران" description="جستجو، ویرایش و مسدودسازی امن و برگشت‌پذیر کاربران" />
    <Card className="toolbar-card"><SearchBox value={search} onChange={value => { setSearch(value); setPage(1) }} placeholder="نام، شماره همراه یا ایمیل" /><div className="filters"><select value={state} onChange={e => {setState(e.target.value);setPage(1)}}><option value="">همه وضعیت‌ها</option><option value="active">فعال</option><option value="banned">مسدود</option></select><select value={plan} onChange={e => {setPlan(e.target.value);setPage(1)}}><option value="">همه پلن‌ها</option><option value="free">رایگان</option><option value="premium">پریمیوم</option></select><select value={`${sort}:${direction}`} onChange={e => {const [s,d]=e.target.value.split(':');setSort(s);setDirection(d);setPage(1)}}><option value="time:desc">جدیدترین</option><option value="time:asc">قدیمی‌ترین</option><option value="name:asc">نام از الف</option><option value="name:desc">نام از ی</option></select></div></Card>
    <Card>{remote.error ? <ErrorState message={remote.error} retry={() => void remote.reload()} /> : <><DataTable<AdminUser> loading={remote.loading} rows={rows} columns={[
      { key:'user', title:'کاربر', render:u => <div className="person-cell"><span className="avatar">{u.first_name?.[0] || 'ک'}</span><div><strong>{`${u.first_name || ''} ${u.last_name || ''}`.trim() || 'بدون نام'}</strong><span dir="ltr">{u.phone_number}</span></div></div> },
      { key:'plan', title:'پلن', render:u => <StatusBadge value={u.plan} tone={u.plan === 'premium' ? 'success' : 'neutral'} /> },
      { key:'state', title:'حساب', render:u => <StatusBadge value={u.is_banned ? 'banned' : 'active'} /> },
      { key:'verified', title:'تأیید', render:u => <div className="verification-stack"><span className={u.is_verified ? 'verified' : 'muted'}>{u.is_verified && <Check size={15}/>}شماره: {u.is_verified ? 'تأیید شده' : 'تأیید نشده'}</span>{u.has_artist_profile && <span className={u.artist_verified ? 'verified' : 'muted'}>{u.artist_verified && <Check size={15}/>}هنرمند: {u.artist_verified ? 'تأیید شده' : 'در انتظار تأیید'}</span>}</div> },
      { key:'joined', title:'عضویت', render:u => dateTimeFa(u.date_joined) },
      { key:'actions', title:'عملیات', render:u => <div className="row-actions"><button className="icon-button" onClick={() => openEdit(u)} title="ویرایش"><Pencil size={17}/></button><button className={`icon-button ${u.is_banned ? 'is-success' : 'is-danger'}`} onClick={() => setBanTarget(u)} title={u.is_banned ? 'رفع مسدودی' : 'مسدود کردن'}>{u.is_banned ? <Unlock size={17}/> : <Ban size={17}/>}</button></div> },
    ]} />{remote.data && <Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage} />}</>}</Card>
    <Modal open={Boolean(selected)} title="ویرایش کاربر" onClose={() => setSelected(null)}>{draft && <div className="form-grid"><Field label="نام"><input value={draft.first_name} onChange={e => setDraft({...draft,first_name:e.target.value})}/></Field><Field label="نام خانوادگی"><input value={draft.last_name} onChange={e => setDraft({...draft,last_name:e.target.value})}/></Field><Field label="ایمیل"><input dir="ltr" value={draft.email} onChange={e => setDraft({...draft,email:e.target.value})}/></Field><Field label="کیفیت پخش"><select value={draft.stream_quality} onChange={e => setDraft({...draft,stream_quality:e.target.value})}><option value="medium">متوسط</option><option value="high">بالا</option></select></Field><div className="dialog-actions form-grid__full"><button className="button button--ghost" onClick={() => setSelected(null)}>انصراف</button><button className="button button--primary" disabled={busy} onClick={saveEdit}><ShieldCheck size={17}/>ذخیره تغییرات</button></div></div>}</Modal>
    <Confirm open={Boolean(banTarget)} title={banTarget?.is_banned ? 'رفع مسدودی کاربر' : 'مسدود کردن کاربر'} text={banTarget?.is_banned ? 'حساب دوباره فعال می‌شود و تمام اطلاعات قبلی دست‌نخورده باقی می‌ماند.' : 'حساب غیرفعال می‌شود، اما هیچ آهنگ، آلبوم، پلی‌لیست یا اطلاعاتی حذف نخواهد شد.'} confirmLabel={banTarget?.is_banned ? 'رفع مسدودی' : 'مسدود کردن'} danger={!banTarget?.is_banned} busy={busy} onConfirm={toggleBan} onClose={() => setBanTarget(null)} />
  </div>
}
