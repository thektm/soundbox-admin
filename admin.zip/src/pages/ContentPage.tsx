import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { CalendarClock, Check, ImagePlus, Megaphone, Music2, Pencil, Plus, Search, Trash2, Volume2, X } from 'lucide-react'
import { Card, Confirm, ErrorState, Field, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { DataTable } from '../components/DataTable'
import { PersianDateTimePicker } from '../components/PersianDateTimePicker'
import { MarqueeText } from '../components/MarqueeText'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, jsonBody, queryString } from '../lib/api'
import { dateTimeFa, dateTimeTehranFa, numberFa } from '../lib/format'
import { useDebouncedValue } from '../lib/hooks'
import type { Paginated, Promotion, Song } from '../lib/types'
import { useRemote } from '../lib/useRemote'

type Tab = 'promotions' | 'banners' | 'audio'
type Banner = { id:number; title:string; title_en?:string; image?:string|null; navigate_link?:string|null; is_active:boolean; created_at:string; updated_at:string }
type AudioAd = { id:number; title:string; title_en?:string; audio_url?:string|null; image_cover?:string|null; navigate_link?:string|null; duration?:number|null; is_active:boolean; created_at:string; updated_at:string }
type DeleteTarget = { kind:'promotion'|'banner'|'audio'; id:number; title:string } | null

const nowIso = () => new Date().toISOString()
const addHoursIso = (hours:number) => new Date(Date.now() + hours * 3600000).toISOString()
const promotionState = (item:Promotion) => !item.is_active ? 'disabled' : item.is_running ? 'running' : new Date(item.starts_at) > new Date() ? 'upcoming' : 'ended'

function TabButton({ active, onClick, icon, children }:{active:boolean;onClick:()=>void;icon:ReactNode;children:ReactNode}) {
  return <button className={active ? 'content-tab is-active' : 'content-tab'} onClick={onClick}>{icon}<span>{children}</span></button>
}

export default function ContentPage() {
  const [tab, setTab] = useState<Tab>('promotions')
  return <div className="page-stack">
    <PageHeader title="مدیریت محتوا" description="پروموت آهنگ، بنرها و تبلیغات صوتی" />
    <div className="content-tabs" role="tablist" aria-label="بخش‌های مدیریت محتوا">
      <TabButton active={tab==='promotions'} onClick={()=>setTab('promotions')} icon={<Megaphone size={18}/>}>پروموت آهنگ</TabButton>
      <TabButton active={tab==='banners'} onClick={()=>setTab('banners')} icon={<ImagePlus size={18}/>}>بنرها</TabButton>
      <TabButton active={tab==='audio'} onClick={()=>setTab('audio')} icon={<Volume2 size={18}/>}>تبلیغ صوتی</TabButton>
    </div>
    {tab==='promotions' && <PromotionsPanel/>}
    {tab==='banners' && <BannersPanel/>}
    {tab==='audio' && <AudioPanel/>}
  </div>
}

function PromotionsPanel() {
  const toast = useToast()
  const [search,setSearch]=useState(''); const q=useDebouncedValue(search)
  const [state,setState]=useState(''); const [page,setPage]=useState(1)
  const [editing,setEditing]=useState<Promotion|null>(null); const [open,setOpen]=useState(false); const [busy,setBusy]=useState(false)
  const [deleteTarget,setDeleteTarget]=useState<DeleteTarget>(null)
  const path='/admin/promotions/'+queryString({q,state,page,page_size:20})
  const remote=useRemote<Paginated<Promotion>>(path,[q,state,page])
  const openCreate=()=>{setEditing(null);setOpen(true)}
  const openEdit=(item:Promotion)=>{setEditing(item);setOpen(true)}
  async function remove(){if(!deleteTarget)return;setBusy(true);try{await api(`/admin/promotions/${deleteTarget.id}/`,{method:'DELETE'});toast.show('پروموت حذف شد.','success');setDeleteTarget(null);await remote.reload()}catch(e){toast.show(errorMessageFa(e),'error')}finally{setBusy(false)}}
  return <>
    <Card className="toolbar-card"><SearchBox value={search} onChange={v=>{setSearch(v);setPage(1)}} placeholder="نام آهنگ یا هنرمند"/><div className="filters"><select value={state} onChange={e=>{setState(e.target.value);setPage(1)}}><option value="">همه وضعیت‌ها</option><option value="running">در حال اجرا</option><option value="upcoming">زمان‌بندی شده</option><option value="ended">پایان یافته</option><option value="disabled">غیرفعال</option></select><button className="button button--primary" onClick={openCreate}><Plus size={17}/>پروموت جدید</button></div></Card>
    <Card className="promotion-list-card">{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<><DataTable<Promotion> loading={remote.loading} rows={remote.data?.results||[]} emptyTitle="پروموتی ثبت نشده است" columns={[
      {key:'song',title:'آهنگ',render:x=><div className="media-cell">{x.cover_image?<img src={x.cover_image} alt="" loading="lazy"/>:<div className="media-placeholder"><Music2 size={18}/></div>}<div><MarqueeText as="strong" text={x.song_title}/><MarqueeText text={x.artist_name}/></div></div>},
      {key:'aggression',title:'شدت نمایش',render:x=><div className="aggression-cell"><strong>{numberFa(x.aggression)}</strong><div className="mini-meter"><i style={{width:`${x.aggression}%`}}/></div></div>},
      {key:'window',title:'بازه اجرا',render:x=><div className="stacked-text"><span>{dateTimeTehranFa(x.starts_at)}</span><small>تا {dateTimeTehranFa(x.ends_at)}</small></div>},
      {key:'state',title:'وضعیت',render:x=><StatusBadge value={promotionState(x)}/>},
      {key:'actions',title:'عملیات',render:x=><div className="row-actions"><button className="icon-button" aria-label="ویرایش پروموت" onClick={()=>openEdit(x)}><Pencil size={16}/></button><button className="icon-button icon-button--danger" aria-label="حذف پروموت" onClick={()=>setDeleteTarget({kind:'promotion',id:x.id,title:x.song_title})}><Trash2 size={16}/></button></div>},
    ]}/>{remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}</>}</Card>
    <PromotionEditor open={open} item={editing} onClose={()=>setOpen(false)} onSaved={async()=>{setOpen(false);await remote.reload()}}/>
    <Confirm open={Boolean(deleteTarget)} title="حذف پروموت" text={`پروموت «${deleteTarget?.title||''}» حذف شود؟`} confirmLabel="حذف" danger busy={busy} onClose={()=>setDeleteTarget(null)} onConfirm={()=>void remove()}/>
  </>
}

function PromotionEditor({open,item,onClose,onSaved}:{open:boolean;item:Promotion|null;onClose:()=>void;onSaved:()=>Promise<void>}) {
  const toast=useToast(); const [busy,setBusy]=useState(false)
  const [songId,setSongId]=useState<number|null>(item?.song||null); const [songLabel,setSongLabel]=useState(item?`${item.song_title} — ${item.artist_name}`:'')
  const [songSearch,setSongSearch]=useState(''); const dq=useDebouncedValue(songSearch)
  const [aggression,setAggression]=useState(item?.aggression||60); const [starts,setStarts]=useState(item?.starts_at||nowIso()); const [ends,setEnds]=useState(item?.ends_at||addHoursIso(24)); const [active,setActive]=useState(item?.is_active??true)
  const songs=useRemote<Paginated<Song>>(open && !songId && dq.trim().length>=2?'/admin/songs/'+queryString({q:dq,status:'published',page_size:8}):null,[open,dq,songId])
  // Reset modal state whenever its source object changes or it opens.
  useEffect(()=>{if(open){setSongId(item?.song||null);setSongLabel(item?`${item.song_title} — ${item.artist_name}`:'');setSongSearch('');setAggression(item?.aggression||60);setStarts(item?.starts_at||nowIso());setEnds(item?.ends_at||addHoursIso(24));setActive(item?.is_active??true)}},[open,item])
  async function submit(e:FormEvent){e.preventDefault();if(!songId){toast.show('ابتدا یک آهنگ منتشرشده انتخاب کنید.','error');return}if(!starts||!ends||new Date(ends)<=new Date(starts)){toast.show('زمان پایان باید بعد از زمان شروع باشد.','error');return}setBusy(true);try{const body={song:songId,aggression:Number(aggression),starts_at:starts,ends_at:ends,is_active:active};await api(item?`/admin/promotions/${item.id}/`:'/admin/promotions/',{method:item?'PATCH':'POST',body:jsonBody(body)});toast.show(item?'پروموت به‌روزرسانی شد.':'پروموت زمان‌بندی شد.','success');await onSaved()}catch(err){toast.show(errorMessageFa(err),'error')}finally{setBusy(false)}}
  return <Modal open={open} title={item?'ویرایش پروموت':'پروموت آهنگ'} onClose={onClose} wide><form className="form-grid promotion-form" onSubmit={submit}>
    <div className="form-grid__full"><Field label="آهنگ منتشرشده" hint="فقط آهنگ‌های منتشرشده قابل پروموت هستند.">{songId?<div className="selected-song"><Check size={18}/><strong>{songLabel}</strong><button type="button" className="icon-button icon-button--sm" aria-label="تغییر آهنگ" onClick={()=>{setSongId(null);setSongLabel('')}}><X size={15}/></button></div>:<><label className="search-box search-box--field"><Search size={18}/><input value={songSearch} onChange={e=>setSongSearch(e.target.value)} placeholder="حداقل دو نویسه از نام آهنگ یا هنرمند"/></label>{songs.loading&&<div className="inline-note">در حال جستجوی آهنگ…</div>}{songs.data?.results?.length?<div className="song-picker song-picker--promotion">{songs.data.results.map(song=><button type="button" key={song.id} onClick={()=>{setSongId(song.id);setSongLabel(`${song.title} — ${song.artist_name}`)}}><span className="song-picker__art">{song.cover_image?<img src={song.cover_image} alt="" loading="lazy"/>:<Music2 size={17}/>}</span><span className="song-picker__copy"><strong>{song.title}</strong><small>{song.artist_name}</small></span></button>)}</div>:null}</>}</Field></div>
    <div className="form-grid__full"><Field label={`شدت نمایش: ${numberFa(aggression)} از ۱۰۰`} hint={aggression===100?'در شدت ۱۰۰، آهنگ در تمام مدت پروموت در جایگاه اول پیشنهادها می‌ماند.':undefined}><div className="range-row"><span>کم</span><input className="range" type="range" min="1" max="100" value={aggression} onChange={e=>setAggression(Number(e.target.value))}/><span>زیاد</span><output>{numberFa(aggression)}</output></div></Field></div>
    <Field label="شروع پروموت"><PersianDateTimePicker value={starts} onChange={setStarts} placeholder="تاریخ و ساعت شروع"/></Field>
    <Field label="پایان پروموت"><PersianDateTimePicker value={ends} onChange={setEnds} placeholder="تاریخ و ساعت پایان"/></Field>
    <label className="switch-row form-grid__full"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/><span className="switch"/><span><strong>پروموت فعال باشد</strong><small>در صورت غیرفعال بودن، زمان‌بندی نگه داشته می‌شود اما در پیشنهادها اثری ندارد.</small></span></label>
    <div className="dialog-actions form-grid__full"><button type="button" className="button button--ghost" onClick={onClose}>انصراف</button><button className="button button--primary" disabled={busy}><CalendarClock size={17}/>{busy?'در حال ذخیره…':'ذخیره پروموت'}</button></div>
  </form></Modal>
}

function BannersPanel(){
  const toast=useToast();const[page,setPage]=useState(1);const[open,setOpen]=useState(false);const[editing,setEditing]=useState<Banner|null>(null);const[busy,setBusy]=useState(false);const[del,setDel]=useState<DeleteTarget>(null)
  const remote=useRemote<Paginated<Banner>>('/admin/ads/banners/'+queryString({page,page_size:20}),[page])
  async function remove(){if(!del)return;setBusy(true);try{await api(`/admin/ads/banners/${del.id}/`,{method:'DELETE'});toast.show('بنر حذف شد.','success');setDel(null);await remote.reload()}catch(e){toast.show(errorMessageFa(e),'error')}finally{setBusy(false)}}
  return <><div className="section-actions"><div><strong>بنرهای پلتفرم</strong><span>مدیریت تصویر، لینک مقصد و وضعیت نمایش</span></div><button className="button button--primary" onClick={()=>{setEditing(null);setOpen(true)}}><Plus size={17}/>بنر جدید</button></div><Card>{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<><DataTable<Banner> loading={remote.loading} rows={remote.data?.results||[]} emptyTitle="بنری ثبت نشده است" columns={[
    {key:'banner',title:'بنر',render:x=><div className="media-cell">{x.image?<img src={x.image} alt="" loading="lazy"/>:<div className="media-placeholder"><ImagePlus size={18}/></div>}<div><strong>{x.title}</strong><span>{x.navigate_link||'بدون لینک مقصد'}</span></div></div>},{key:'state',title:'نمایش',render:x=><StatusBadge value={x.is_active?'active':'disabled'}/>},{key:'time',title:'ایجاد',render:x=>dateTimeFa(x.created_at)},{key:'actions',title:'عملیات',render:x=><div className="row-actions"><button className="icon-button" onClick={()=>{setEditing(x);setOpen(true)}} aria-label="ویرایش بنر"><Pencil size={16}/></button><button className="icon-button icon-button--danger" onClick={()=>setDel({kind:'banner',id:x.id,title:x.title})} aria-label="حذف بنر"><Trash2 size={16}/></button></div>}
  ]}/>{remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}</>}</Card><BannerEditor open={open} item={editing} onClose={()=>setOpen(false)} onSaved={async()=>{setOpen(false);await remote.reload()}}/><Confirm open={Boolean(del)} title="حذف بنر" text={`بنر «${del?.title||''}» حذف شود؟`} confirmLabel="حذف" danger busy={busy} onClose={()=>setDel(null)} onConfirm={()=>void remove()}/></>
}

function BannerEditor({open,item,onClose,onSaved}:{open:boolean;item:Banner|null;onClose:()=>void;onSaved:()=>Promise<void>}){
 const toast=useToast();const[busy,setBusy]=useState(false);const[title,setTitle]=useState(item?.title||'');const[titleEn,setTitleEn]=useState(item?.title_en||'');const[link,setLink]=useState(item?.navigate_link||'');const[active,setActive]=useState(item?.is_active??true);const[file,setFile]=useState<File|null>(null)
 useEffect(()=>{if(open){setTitle(item?.title||'');setTitleEn(item?.title_en||'');setLink(item?.navigate_link||'');setActive(item?.is_active??true);setFile(null)}},[open,item])
 async function submit(e:FormEvent){e.preventDefault();setBusy(true);try{const f=new FormData();f.append('title',title);f.append('title_en',titleEn);f.append('navigate_link',link);f.append('is_active',String(active));if(file)f.append('image_upload',file);await api(item?`/admin/ads/banners/${item.id}/`:'/admin/ads/banners/',{method:item?'PATCH':'POST',body:f});toast.show(item?'بنر به‌روزرسانی شد.':'بنر ایجاد شد.','success');await onSaved()}catch(err){toast.show(errorMessageFa(err),'error')}finally{setBusy(false)}}
 return <Modal open={open} title={item?'ویرایش بنر':'بنر جدید'} onClose={onClose}><form className="form-grid" onSubmit={submit}><Field label="عنوان فارسی"><input value={title} onChange={e=>setTitle(e.target.value)} required/></Field><Field label="عنوان انگلیسی"><input dir="ltr" value={titleEn} onChange={e=>setTitleEn(e.target.value)} required/></Field><div className="form-grid__full"><Field label="لینک مقصد"><input dir="ltr" value={link} onChange={e=>setLink(e.target.value)} placeholder="نشانی مقصد"/></Field></div><div className="form-grid__full"><Field label="تصویر بنر" hint={item?'اگر تصویر جدید انتخاب نکنید، تصویر فعلی حفظ می‌شود.':'یک تصویر بنر انتخاب کنید.'}><input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)} required={!item}/></Field></div><label className="switch-row form-grid__full"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/><span className="switch"/><span><strong>نمایش بنر فعال باشد</strong></span></label><div className="dialog-actions form-grid__full"><button type="button" className="button button--ghost" onClick={onClose}>انصراف</button><button className="button button--primary" disabled={busy}>{busy?'در حال ذخیره…':'ذخیره بنر'}</button></div></form></Modal>
}


function AudioPanel(){
 const toast=useToast();const[page,setPage]=useState(1);const[open,setOpen]=useState(false);const[editing,setEditing]=useState<AudioAd|null>(null);const[busy,setBusy]=useState(false);const[del,setDel]=useState<DeleteTarget>(null)
 const remote=useRemote<Paginated<AudioAd>>('/admin/ads/audio/'+queryString({page,page_size:20}),[page])
 async function remove(){if(!del)return;setBusy(true);try{await api(`/admin/ads/audio/${del.id}/`,{method:'DELETE'});toast.show('تبلیغ صوتی حذف شد.','success');setDel(null);await remote.reload()}catch(e){toast.show(errorMessageFa(e),'error')}finally{setBusy(false)}}
 return <><div className="section-actions"><div><strong>تبلیغات صوتی</strong><span>فایل صوتی، کاور و لینک مقصد</span></div><button className="button button--primary" onClick={()=>{setEditing(null);setOpen(true)}}><Plus size={17}/>تبلیغ جدید</button></div><Card>{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<><DataTable<AudioAd> loading={remote.loading} rows={remote.data?.results||[]} emptyTitle="تبلیغ صوتی ثبت نشده است" columns={[
 {key:'name',title:'تبلیغ',render:x=><div className="media-cell">{x.image_cover?<img src={x.image_cover} alt="" loading="lazy"/>:<div className="media-placeholder"><Volume2 size={18}/></div>}<div><strong>{x.title}</strong><span>{x.duration?`${numberFa(x.duration)} ثانیه`:'مدت نامشخص'}</span></div></div>},{key:'state',title:'وضعیت',render:x=><StatusBadge value={x.is_active?'active':'disabled'}/>},{key:'actions',title:'عملیات',render:x=><div className="row-actions"><button className="icon-button" onClick={()=>{setEditing(x);setOpen(true)}} aria-label="ویرایش تبلیغ"><Pencil size={16}/></button><button className="icon-button icon-button--danger" onClick={()=>setDel({kind:'audio',id:x.id,title:x.title})} aria-label="حذف تبلیغ"><Trash2 size={16}/></button></div>}
 ]}/>{remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}</>}</Card><AudioEditor open={open} item={editing} onClose={()=>setOpen(false)} onSaved={async()=>{setOpen(false);await remote.reload()}}/><Confirm open={Boolean(del)} title="حذف تبلیغ صوتی" text={`تبلیغ «${del?.title||''}» حذف شود؟`} confirmLabel="حذف" danger busy={busy} onClose={()=>setDel(null)} onConfirm={()=>void remove()}/></>
}

function AudioEditor({open,item,onClose,onSaved}:{open:boolean;item:AudioAd|null;onClose:()=>void;onSaved:()=>Promise<void>}){
 const toast=useToast();const[busy,setBusy]=useState(false);const[title,setTitle]=useState('');const[titleEn,setTitleEn]=useState('');const[link,setLink]=useState('');const[active,setActive]=useState(true);const[audio,setAudio]=useState<File|null>(null);const[cover,setCover]=useState<File|null>(null)
 useEffect(()=>{if(open){setTitle(item?.title||'');setTitleEn(item?.title_en||'');setLink(item?.navigate_link||'');setActive(item?.is_active??true);setAudio(null);setCover(null)}},[open,item])
 async function submit(e:FormEvent){e.preventDefault();if(!item&&!audio){toast.show('فایل صوتی تبلیغ را انتخاب کنید.','error');return}setBusy(true);try{const f=new FormData();f.append('title',title);f.append('title_en',titleEn);f.append('navigate_link',link);f.append('is_active',String(active));if(audio)f.append('audio_upload',audio);if(cover)f.append('image_cover_upload',cover);await api(item?`/admin/ads/audio/${item.id}/`:'/admin/ads/audio/',{method:item?'PATCH':'POST',body:f});toast.show(item?'تبلیغ صوتی به‌روزرسانی شد.':'تبلیغ صوتی ایجاد شد.','success');await onSaved()}catch(err){toast.show(errorMessageFa(err),'error')}finally{setBusy(false)}}
 return <Modal open={open} title={item?'ویرایش تبلیغ صوتی':'تبلیغ صوتی جدید'} onClose={onClose}><form className="form-grid" onSubmit={submit}><Field label="عنوان فارسی"><input value={title} onChange={e=>setTitle(e.target.value)} required/></Field><Field label="عنوان انگلیسی"><input dir="ltr" value={titleEn} onChange={e=>setTitleEn(e.target.value)} required/></Field><div className="form-grid__full"><Field label="لینک مقصد"><input dir="ltr" value={link} onChange={e=>setLink(e.target.value)} placeholder="نشانی مقصد"/></Field></div><Field label="فایل صوتی"><input type="file" accept="audio/*" onChange={e=>setAudio(e.target.files?.[0]||null)}/></Field><Field label="تصویر کاور"><input type="file" accept="image/*" onChange={e=>setCover(e.target.files?.[0]||null)}/></Field><label className="switch-row form-grid__full"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/><span className="switch"/><span><strong>تبلیغ فعال باشد</strong></span></label><div className="dialog-actions form-grid__full"><button type="button" className="button button--ghost" onClick={onClose}>انصراف</button><button className="button button--primary" disabled={busy}>{busy?'در حال ذخیره…':'ذخیره تبلیغ'}</button></div></form></Modal>
}
