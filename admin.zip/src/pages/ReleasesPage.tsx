import { useState } from 'react'
import { CheckCircle2, Eye, FilePenLine, Radio, RotateCcw, Send, ShieldX, Timer, XCircle } from 'lucide-react'
import { DataTable } from '../components/DataTable'
import { Card, ErrorState, Field, Modal, PageHeader, Pagination, SearchBox, StatusBadge } from '../components/Ui'
import { useToast } from '../components/Toast'
import { api, errorMessageFa, jsonBody, queryString } from '../lib/api'
import { useDebouncedValue } from '../lib/hooks'
import { dateTimeFa, numberFa } from '../lib/format'
import type { Paginated } from '../lib/types'
import { useRemote } from '../lib/useRemote'

type ReleaseActionResult = Release | { id:string; removed_from_admin_queue:true }
type Release = Record<string, unknown> & { id:string; title:string; title_en?:string; status:string; release_type?:string; created_at?:string; updated_at?:string; artist?: {id:number;name?:string;artistic_name?:string}; artist_name?:string; tracks?: Array<Record<string, unknown> & {id:number;title:string;artist_name?:string;duration_display?:string;status?:string}>; validation?: {valid?:boolean;errors?:unknown[];warnings?:unknown[];summary?:Record<string,unknown>}; release_metadata?:Record<string,unknown>; history?:Array<Record<string,unknown>>; admin_note?:string; review_note?:string }

const actionMap: Record<string, { label:string; icon:typeof CheckCircle2; tone?:string }> = {
  request_changes:{label:'درخواست اصلاح',icon:FilePenLine}, reject:{label:'رد انتشار',icon:XCircle,tone:'danger'}, approve:{label:'تأیید',icon:CheckCircle2},
  schedule:{label:'زمان‌بندی',icon:Timer}, publish:{label:'انتشار فوری',icon:Radio}, take_down:{label:'خارج کردن از دسترس',icon:ShieldX,tone:'danger'},
  reopen:{label:'بازگشایی برای ویرایش',icon:RotateCcw}, return_to_review:{label:'بازگردانی به بررسی',icon:Send},
}
const allowed: Record<string,string[]> = {
  in_review:['request_changes','reject','approve','schedule','publish'], changes_requested:['reject','reopen','return_to_review'], approved:['schedule','publish','return_to_review'], scheduled:['publish'], live:['take_down'], rejected:['reopen','return_to_review'], taken_down:['reopen','publish'],
}

export default function ReleasesPage(){
  const [search,setSearch]=useState(''); const [status,setStatus]=useState(''); const [page,setPage]=useState(1)
  const [selected,setSelected]=useState<Release|null>(null); const [note,setNote]=useState(''); const [busy,setBusy]=useState(false)
  const q=useDebouncedValue(search); const toast=useToast(); const path='/admin/releases/'+queryString({q,status,page,page_size:20})
  const remote=useRemote<Paginated<Release>>(path,[q,status,page])
  async function open(item:Release){try{setSelected(await api<Release>(`/admin/releases/${item.id}/`));setNote('')}catch(err){toast.show(errorMessageFa(err),'error')}}
  async function act(action:string){if(!selected)return;setBusy(true);try{const result=await api<ReleaseActionResult>(`/admin/releases/${selected.id}/action/`,{method:'POST',body:jsonBody({action,note})});if('removed_from_admin_queue' in result){setSelected(null)}else{setSelected(result)}setNote('');toast.show(action==='reopen'?'انتشار برای ویرایش هنرمند باز شد و از صف ادمین خارج شد.':'عملیات انتشار با موفقیت انجام شد.','success');await remote.reload()}catch(err){toast.show(errorMessageFa(err),'error')}finally{setBusy(false)}}
  return <div className="page-stack"><PageHeader title="بررسی انتشارها" description="کنترل کامل چرخه بررسی، تأیید، زمان‌بندی و انتشار آثار"/>
    <Card className="toolbar-card"><SearchBox value={search} onChange={v=>{setSearch(v);setPage(1)}} placeholder="نام انتشار یا هنرمند"/><div className="filters"><select value={status} onChange={e=>{setStatus(e.target.value);setPage(1)}}><option value="">همه وضعیت‌ها</option><option value="in_review">در حال بررسی</option><option value="changes_requested">نیازمند اصلاح</option><option value="approved">تأیید شده</option><option value="scheduled">زمان‌بندی شده</option><option value="live">منتشر شده</option><option value="rejected">رد شده</option><option value="taken_down">خارج از دسترس</option></select></div></Card>
    <Card>{remote.error?<ErrorState message={remote.error} retry={()=>void remote.reload()}/>:<><DataTable<Release> loading={remote.loading} rows={remote.data?.results||[]} columns={[
      {key:'title',title:'انتشار',render:r=><div><strong>{r.title}</strong><div className="subline">{r.artist_name || (r.artist && (r.artist.artistic_name||r.artist.name)) || '—'}</div></div>},
      {key:'type',title:'نوع',render:r=>r.release_type==='album'?'آلبوم':'تک‌آهنگ'}, {key:'status',title:'وضعیت',render:r=><StatusBadge value={r.status}/>},
      {key:'tracks',title:'ترک‌ها',render:r=>numberFa(r.tracks?.length||0)}, {key:'updated',title:'آخرین تغییر',render:r=>dateTimeFa(String(r.updated_at||r.created_at||''))},
      {key:'action',title:'بررسی',render:r=><button className="button button--compact" onClick={()=>void open(r)}><Eye size={16}/>جزئیات</button>},
    ]}/>{remote.data&&<Pagination count={remote.data.count} page={page} pageSize={20} onPage={setPage}/>}</>}</Card>
    <Modal open={Boolean(selected)} title="جزئیات انتشار" onClose={()=>setSelected(null)} wide>{selected&&<div className="release-detail"><div className="release-hero"><div><span>عنوان انتشار</span><h3>{selected.title}</h3><p>{selected.artist_name || (selected.artist && (selected.artist.artistic_name||selected.artist.name)) || '—'}</p></div><StatusBadge value={selected.status}/></div>
      {selected.validation&&<div className={`validation-box ${selected.validation.valid?'is-valid':'is-invalid'}`}><strong>{selected.validation.valid?'اعتبارسنجی انتشار موفق است':'انتشار خطای اعتبارسنجی دارد'}</strong><span>{selected.validation.valid?'این انتشار از نظر اطلاعات موردنیاز آماده عملیات بعدی است.':'پیش از تأیید یا انتشار، خطاهای اعتبارسنجی باید رفع شوند.'}</span></div>}
      <div className="detail-block"><span>ترک‌های انتشار</span><div className="track-list">{selected.tracks?.map((track,index)=><div key={track.id}><b>{numberFa(index+1)}</b><div><strong>{track.title}</strong><span>{track.duration_display||'—'}</span></div><StatusBadge value={track.status}/></div>)||<span className="muted">ترکی ثبت نشده است.</span>}</div></div>
      <Field label="یادداشت مدیر"><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="در صورت نیاز توضیح کوتاه برای این عملیات بنویسید…"/></Field>
      <div className="action-grid">{(allowed[selected.status]||[]).map(key=>{const item=actionMap[key];const Icon=item.icon;return <button key={key} className={`button ${item.tone==='danger'?'button--danger':key==='approve'||key==='publish'?'button--primary':'button--ghost'}`} disabled={busy} onClick={()=>void act(key)}><Icon size={17}/>{item.label}</button>})}</div>
    </div>}</Modal>
  </div>
}
