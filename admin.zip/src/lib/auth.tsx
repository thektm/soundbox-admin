import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { adminLogout, session, sessionEventName, type StoredAdmin } from './api'

type AuthValue = { user: StoredAdmin | null; signedIn: boolean; setUser: (user: StoredAdmin | null) => void; logout: () => Promise<void> }
const AuthContext = createContext<AuthValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<StoredAdmin | null>(() => session.user())
  useEffect(() => {
    const sync = () => setUser(session.user())
    window.addEventListener(sessionEventName, sync)
    return () => window.removeEventListener(sessionEventName, sync)
  }, [])
  const value = useMemo<AuthValue>(() => ({
    user,
    signedIn: Boolean(user && session.access()),
    setUser,
    logout: async () => { await adminLogout(); setUser(null) },
  }), [user])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const value = useContext(AuthContext)
  if (!value) throw new Error('سامانه ورود آماده نیست.')
  return value
}
