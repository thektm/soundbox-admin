import { useCallback, useEffect, useRef, useState } from 'react'
import { api, errorMessageFa } from './api'

export function useRemote<T>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(Boolean(path))
  const [error, setError] = useState('')
  const requestId = useRef(0)

  const reload = useCallback(async () => {
    if (!path) { setLoading(false); return null }
    const id = ++requestId.current
    setLoading(true); setError('')
    try {
      const result = await api<T>(path)
      if (id === requestId.current) setData(result)
      return result
    } catch (err) {
      if (id === requestId.current) setError(errorMessageFa(err))
      return null
    } finally {
      if (id === requestId.current) setLoading(false)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps])

  useEffect(() => { void reload() }, [reload])
  return { data, setData, loading, error, reload }
}
